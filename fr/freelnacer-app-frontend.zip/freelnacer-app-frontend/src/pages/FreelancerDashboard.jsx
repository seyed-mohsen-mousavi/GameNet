import DashboardLayout from "../features/freelnacer/DashboardLayout";

function FreelancerDashboard() {
  return <DashboardLayout />;
}
export default FreelancerDashboard;
