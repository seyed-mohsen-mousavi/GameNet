import DashboardLayout from "../features/admin/DashboardLayout";

function AdminDashboard() {
  return <DashboardLayout />;
}
export default AdminDashboard;
