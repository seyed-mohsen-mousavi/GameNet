import ProjectHeader from "../features/freelnacer/projects/ProjectsHeader";
import ProjectTable from "../features/freelnacer/projects/ProjectsTable";

function SubmittedProjects() {
  return (
    <div>
      <ProjectHeader />
      <ProjectTable />
    </div>
  );
}
export default SubmittedProjects;
