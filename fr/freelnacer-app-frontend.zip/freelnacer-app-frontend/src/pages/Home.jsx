function Home() {
  return (
    <div className="h-screen bg-secondary-0">
      <div className="container xl:max-w-screen-xl">
        <h1 className="p-4 text-xl text-secondary-700">صفحه اصلی</h1>
      </div>
    </div>
  );
}
export default Home;
