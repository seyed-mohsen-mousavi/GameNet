import DashboardLayout from "../features/owner/DashboardLayout";

function OwnerDashboard() {
  return <DashboardLayout />;
}
export default OwnerDashboard;
