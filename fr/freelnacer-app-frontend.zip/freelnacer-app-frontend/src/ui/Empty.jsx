function Empty({ resourceName }) {
  return (
    <p className="font-bold text-secondary-700"> {resourceName} یافت نشد.</p>
  );
}
export default Empty;
